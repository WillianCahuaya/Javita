package com.autonoma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutonomaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutonomaApplication.class, args);
	}

}
