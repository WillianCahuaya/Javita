package com.autonoma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutonomaApplicationTests {

	@Test
	void contextLoads() {
	}

}
